//
//  SignUpViewController.swift
//  madShell
//
//  Created by Student on 16.03.2022.
//

import UIKit

class SignUpViewController: UIViewController {

    @IBOutlet weak var EmailFieldView: UIView!
    @IBOutlet weak var EmailTxt: UITextField!
    
    @IBOutlet weak var PasswordFieldView: UIView!
    @IBOutlet weak var PasswordTxt: UITextField!
    
    @IBOutlet weak var RepeatPasswordFieldView: UIView!
    @IBOutlet weak var RepeatPasswordTxt: UITextField!
    
    @IBOutlet weak var signupCompanyButton: UIButton!
    @IBOutlet weak var SignUpButton: UIButton!
    
    //sign up (company)
    @IBOutlet weak var companyNameFieldView: UIView!
    @IBOutlet weak var companyNameTxt: UITextField!
    
    @IBOutlet weak var signupParticipantButton: UIButton!
    @IBAction func signupParticipantAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configurateViews()
        // Do any additional setup after loading the view.
    }
    
    func configurateViews() {
        //log in button - border
        //LogInButton.layer.cornerRadius = 0
        
        //text field Email
        EmailFieldView.backgroundColor = .clear
        EmailFieldView.layer.borderColor = UIColor.black.cgColor
        EmailFieldView.layer.borderWidth = 1
        EmailFieldView.layer.cornerRadius = 0
        
        //text field company name
        companyNameFieldView.backgroundColor = .clear
        companyNameFieldView.layer.borderColor = UIColor.black.cgColor
        companyNameFieldView.layer.borderWidth = 1
        companyNameFieldView.layer.cornerRadius = 0
        
        //text field password
        PasswordFieldView.backgroundColor = .clear
        PasswordFieldView.layer.borderColor = UIColor.black.cgColor
        PasswordFieldView.layer.borderWidth = 1
        PasswordFieldView.layer.cornerRadius = 0
        
        //repeat password
        RepeatPasswordFieldView.backgroundColor = .clear
        RepeatPasswordFieldView.layer.borderColor = UIColor.black.cgColor
        RepeatPasswordFieldView.layer.borderWidth = 1
        RepeatPasswordFieldView.layer.cornerRadius = 0
        
        //placeholder color
        EmailTxt.attributedPlaceholder = NSAttributedString(
            string: "E-mail",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray]
        )
        PasswordTxt.attributedPlaceholder = NSAttributedString(
            string: "Password",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray]
        )
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
