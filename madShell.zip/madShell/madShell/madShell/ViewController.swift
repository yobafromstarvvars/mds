//
//  ViewController.swift
//  madShell
//
//  Created by Student on 16.03.2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var EmailFieldView: UIView!
    @IBOutlet weak var EmailTxt: UITextField!
    
    @IBOutlet weak var PasswordFieldView: UIView!
    @IBOutlet weak var PasswordTxt: UITextField!
    
    @IBOutlet weak var SignUpButton: UIButton!
    @IBOutlet weak var ForgotPasswordButton: UIButton!
    @IBOutlet weak var LogInButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        configurateViews()
    }
    
    
    func configurateViews() {
        //log in button - border
        LogInButton.layer.cornerRadius = 0
        
        //text field Email
        EmailFieldView.backgroundColor = .clear
        EmailFieldView.layer.borderColor = UIColor.black.cgColor
        EmailFieldView.layer.borderWidth = 1
        EmailFieldView.layer.cornerRadius = 0
        
        //text field password
        PasswordFieldView.backgroundColor = .clear
        PasswordFieldView.layer.borderColor = UIColor.black.cgColor
        PasswordFieldView.layer.borderWidth = 1
        PasswordFieldView.layer.cornerRadius = 0
        
        //placeholder color
        EmailTxt.attributedPlaceholder = NSAttributedString(
            string: "E-mail",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray]
        )
        PasswordTxt.attributedPlaceholder = NSAttributedString(
            string: "Password",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray]
        )
    }

}

