//
//  LogInViewController.swift
//  WorldCinemaDesign
//
//  Created by Student on 14.03.2022.
//

import UIKit

class LogInViewController: UIViewController {

    @IBOutlet weak var SignUpButton: UIButton!
    
    @IBOutlet weak var LogInButton: UIButton!
    
    @IBOutlet weak var EmailTxt: UITextField!
    
    @IBOutlet weak var PasswordTxt: UITextField!
    
    @IBOutlet weak var EmailFieldView: UIView!
    
    @IBOutlet weak var PasswordFieldView: UIView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configurateViews()
        // Do any additional setup after loading the view.
    }
    
    
    
    func configurateViews() {
        //sing up button - border
        SignUpButton.layer.borderColor = UIColor.white.cgColor
        SignUpButton.layer.borderWidth = 1
        SignUpButton.layer.cornerRadius = 4
        
        //log in button - border
        LogInButton.layer.cornerRadius = 4
        
        //text field Email
        EmailFieldView.backgroundColor = .clear
        EmailFieldView.layer.borderColor = UIColor.gray.cgColor
        EmailFieldView.layer.borderWidth = 1
        EmailFieldView.layer.cornerRadius = 4
        
        //text field password
        PasswordFieldView.backgroundColor = .clear
        PasswordFieldView.layer.borderColor = UIColor.gray.cgColor
        PasswordFieldView.layer.borderWidth = 1
        PasswordFieldView.layer.cornerRadius = 4
    }
    
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
