//
//  SignUpViewController.swift
//  WorldCinemaDesign
//
//  Created by Student on 15.03.2022.
//

import UIKit

class SignUpViewController: UIViewController {

    @IBOutlet weak var firstNameFieldView: UIView!
    @IBOutlet weak var firstNameTxt: UITextField!
    
    @IBOutlet weak var lastNameFieldView: UIView!
    @IBOutlet weak var lastNameTxt: UITextField!
    
    @IBOutlet weak var emailFieldView: UIView!
    @IBOutlet weak var emailTxt: UITextField!
    
    @IBOutlet weak var passwordFieldView: UIView!
    @IBOutlet weak var passwordTxt: UITextField!
    
    @IBOutlet weak var repeatPasswordFieldView: UIView!
    @IBOutlet weak var repeatPasswordTxt: UITextField!
    
    @IBOutlet weak var signUpButton: UIButton!
    @IBAction func signUpButtonAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var logInButton: UIButton!
    @IBAction func logInButtonAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        configurateViews()
    }
    
    
    func configurateViews() {
        //BUTTONS
        //sing up button - border
        logInButton.layer.borderColor = UIColor.gray.cgColor
        logInButton.layer.borderWidth = 1
        logInButton.layer.cornerRadius = 4
        
        //log in button - border
        signUpButton.layer.cornerRadius = 4
        
        // Already have an account (go back)
        
        
        
        
        //TEXT FIELDS
        // First Name
        firstNameFieldView.backgroundColor = .clear
        firstNameFieldView.layer.borderColor = UIColor.gray.cgColor
        firstNameFieldView.layer.borderWidth = 1
        firstNameFieldView.layer.cornerRadius = 4
        
        // Last Name
        lastNameFieldView.backgroundColor = .clear
        lastNameFieldView.layer.borderColor = UIColor.gray.cgColor
        lastNameFieldView.layer.borderWidth = 1
        lastNameFieldView.layer.cornerRadius = 4
        
        // Email
        emailFieldView.backgroundColor = .clear
        emailFieldView.layer.borderColor = UIColor.gray.cgColor
        emailFieldView.layer.borderWidth = 1
        emailFieldView.layer.cornerRadius = 4
        
        // Password
        passwordFieldView.backgroundColor = .clear
        passwordFieldView.layer.borderColor = UIColor.gray.cgColor
        passwordFieldView.layer.borderWidth = 1
        passwordFieldView.layer.cornerRadius = 4
        
        // Repeat Password
        repeatPasswordFieldView.backgroundColor = .clear
        repeatPasswordFieldView.layer.borderColor = UIColor.gray.cgColor
        repeatPasswordFieldView.layer.borderWidth = 1
        repeatPasswordFieldView.layer.cornerRadius = 4
        
        
        
        // Placeholder color
        firstNameTxt.attributedPlaceholder = NSAttributedString(
            string: "First name",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray]
        )
        lastNameTxt.attributedPlaceholder = NSAttributedString(
            string: "Last name",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray]
        )
        emailTxt.attributedPlaceholder = NSAttributedString(
            string: "E-mail",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray]
        )
        passwordTxt.attributedPlaceholder = NSAttributedString(
            string: "Password",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray]
        )
        repeatPasswordTxt.attributedPlaceholder = NSAttributedString(
            string: "Repeat password",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray]
        )
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
